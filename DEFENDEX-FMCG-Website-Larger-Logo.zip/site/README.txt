DEFENDEX — Version 2 Website + Image Upgrade

Package contents
- index.html — complete one-page website
- styles.css — responsive styling and image treatments
- script.js — project filters, project modal, mobile menu and enquiry form
- assets/defendex-logo.png — supplied DEFENDEX logo
- assets/images/ — local website imagery used across hero, about, services and project cards

Image upgrade
- Added a premium full-width hero visual with Qatar-inspired skyline, modern building, MEP, security, electrical, landscaping and engineering imagery.
- Added a dedicated About visual.
- Added service-card imagery for MEP, ELV & Security, Facilities Management and Testing/Commissioning.
- Added a Qatar skyline image strip.
- Added visual backgrounds to project reference cards.
- Images are stored locally in the package so the visual sections do not depend on external image URLs.

Content basis
Company/service/project content follows the supplied DEFENDEX company profile and project references. The supplied profile covers Civil, MEP, ELV & Security, Facilities Management, Landscaping & Outdoor Services, Testing & Commissioning, maintenance programmes and project references across Qatar.

Contact numbers currently shown
- +974 7738 3614
- +974 4433 5890
- +974 7142 4201
- +974 7724 3033
- info@defendexco.com

How to preview
1. Extract the ZIP.
2. Open index.html in a modern browser.
3. For best results, serve the folder through a simple local web server.

Deployment
Upload the entire defendex-website-v2 folder to your hosting provider. No database or server-side application is required for the current static version.

Note
The hero visual is an original generated design created for this website. The Qatar skyline image is taken from the supplied DEFENDEX company profile artwork. Verify final company/legal details, project status and contact information before production launch.

FMCGs service added: Tomato Paste, Natural Honey, Olive Oil and Salt.


Latest visual update
- Services retain their dedicated local imagery with stronger image visibility and hover treatment.
- Sector cards now use distinct local visuals (no repeated sector photos), with dark overlays for readable text and responsive behavior.

Website update: added FMCG item "Other Food Products", Fire Alarm & Fire Fighting, ACMV, WhatsApp enquiry button, enquiry number +974 7738 3614, and removed office +974 4433 5890 and mobile +974 7724 3033.

Website update: FMCG now includes Other Food Products; added Fire Alarm & Fire Fighting and ACMV services with imagery; enquiry number is +974 7738 3614; removed office +974 4433 5890 and mobile +974 7724 3033; added WhatsApp enquiry buttons.
